#include <stdio.h>
#include <conio.h>
// #define TRUE 1
// #define FALSE 0

// inc -> x wala array hai
// wt is the sum of the subset being computed 
// total is the remaining sum
// sum is the sum of the subset which we want
// w[]=array of elements in the original set

int inc[50], w[50], sum, n;
int promising(int i, int wt, int total){
    return (((wt + total) >= sum) && ((wt == sum) || (wt + w[i + 1] <= sum)));
}

void sumset(int i, int wt, int total){
    int j;
    if (promising(i, wt, total)){
        if (wt == sum){
            printf("\n{ ");
            for (j = 0; j <= i; j++)
                if (inc[j])
                    printf("%d,", w[j]);
            printf("}\n");
        }
        else{
            inc[i + 1] = 1;
            sumset(i + 1, wt + w[i + 1], total - w[i + 1]);
            inc[i + 1] = 0;
            sumset(i + 1, wt, total - w[i + 1]);
        }
    }
}

void main(){
    int i, j, n, temp, total = 0;

    printf("\n Enter how many numbers:\n");
    scanf("%d", &n);
    printf("\n Enter %d numbers to the set in ascending order:\n", n);
    for (i = 0; i < n; i++){
        scanf("%d", &w[i]);
        total += w[i];
    }
    printf("\n Input the sum value to create sub set:\n");
    scanf("%d", &sum);
    if ((total < sum))
        printf("\n Subset construction is not possible");
    else{
        for (i = 0; i < n; i++)
            inc[i] = 0;
        printf("\n The solution using backtracking is:\n");
        sumset(-1, 0, total);
    }
}
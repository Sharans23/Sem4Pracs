#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int x[20];

int place(int k,int i){
    for(int j=1;j<k;j++){
        if(x[j]==i||((abs(x[j]-i))==(abs(j-k))))
        return 0;
    }
    return 1;
}
void nqueen(int k,int n){
    for(int i=1;i<=n;i++)
    {
        if(place(k,i)){
            x[k]=i;
            if(k==n){
                printf("Sequence:\n");
                for(int j=1;j<=n;j++){
                    for(int k=1;k<=n;k++){
                        if(k==x[j])
                        printf("Q%d\t",j);
                        else
                        printf("*\t");
                    }
                    printf("\n");
                }
            }
            else{
                nqueen(k+1,n);
            }
        }
    }
}
void main(){
    int n;
    printf("enter the number of queens:\n");
    scanf("%d",&n);
    nqueen(1,n);
}
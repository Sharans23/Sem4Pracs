#include<stdio.h>

int pivot,temp,i,j;
void quicksort(int a[25], int start,int end){
    if(start<end){
        pivot=start;
        i=start;
        j=end;
        while(i<j){

            while(a[i]<=a[pivot] && i<end){
                i++;
            }
            while(a[j]>a[pivot]){
                j--;
            }
            if(i<j){
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        }
        temp=a[j];
        a[j]=a[pivot];
        a[pivot]=temp;
        quicksort(a,start,j-1);
        quicksort(a,j+1,end);
    }
}
void main(){
    int n;
    int a[25];
    printf("Enter the number of elements:\n");
    scanf("%d",&n);
    printf("Enter %d elements: ", n);
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]); // a[i]=rand();
    quicksort(a,0,n-1);
    printf("Sorted Array:\n");
    for (i = 0; i < n; i++)
        printf("%d\t", a[i]);    
}
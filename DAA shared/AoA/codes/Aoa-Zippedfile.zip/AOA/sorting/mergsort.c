#include <stdio.h>
#include<time.h>

void merge( int a[],int low,int mid,int high){
    int i=low;
    int j=mid+1;
    int k=low;
    int brr[10000];
    while(i<=mid && j<=high){
        if(a[i]<a[j]){
            brr[k]=a[i];
            i++;
        }
        else{
            brr[k]=a[j];
            j++;
        }
            k++;
    }
    while(i<=mid){
        brr[k]=a[i];
        i++;
        k++;
    }
    while(j<=high){
        brr[k]=a[j];
        j++;
        k++;
    }
    for(int i=low;i<=high;i++){
        a[i]=brr[i];
    }
}

void mergesort(int a[], int low, int high){

    int mid=(low+high)/2;

    if(low<high){

        mergesort(a,low,mid);
        mergesort(a,mid+1,high);
        merge(a,low,mid,high);

    }
}
void main(){
    int n; 
    printf("Enter the number of elements:\n");
    scanf("%d",&n);
    int a[n];
    for(int i=0;i<n;i++){
        a[i]=rand();
    }
    double start= clock();
    mergesort(a,0,n-1);
    double end=clock();
    double diff=(end-start)/CLOCKS_PER_SEC;
    printf("The time taken is:%f\n",diff);
}
//take no of elements as 10,000
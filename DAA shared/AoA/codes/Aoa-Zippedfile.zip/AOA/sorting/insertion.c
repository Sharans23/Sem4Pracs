#include<stdio.h>
#include<stdlib.h>

void main(){
    int n,temp;
    int a[20];
    printf("Enter the number of elements:\n");
    scanf("%d",&n);
    printf("Enter the  elements:\n");
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Unsorted Array:\n");
    for(int i=0;i<n;i++){
        printf("%d\t",a[i]);
    }
    for(int i=1;i<n;i++){
        temp=a[i];
        int j=i-1;
        while(j>=0 && a[j]>temp){                               //dont forget j>=0 and a[j+1]>a[j]
            a[j+1]=a[j];
            j--;

        }
        a[j+1]=temp;
    }
    printf("\nSorted Array:\n");
    for(int i=0;i<n;i++){
        printf("%d\t",a[i]);
    }
   
}
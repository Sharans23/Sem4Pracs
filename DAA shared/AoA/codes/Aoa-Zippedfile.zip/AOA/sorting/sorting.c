#include<stdio.h>
void main(){
     int n,temp,min;
    int a[20];
    printf("Enter the number of elements:\n");
    scanf("%d",&n);
    printf("Enter the  elements:\n");
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Unsorted Array:\n");
    for(int i=0;i<n;i++){
        printf("%d\t",a[i]);
    }
    for(int i=0;i<n;i++){
        min=i;
        for(int j=i+1;j<n;j++){
            if(a[j]<a[min]){
                min=j;
            }
        }
        temp=a[i];
        a[i]=a[min];
        a[min]=temp;
    }
    printf("Sorted Array:\n");
    for(int i=0;i<n;i++){
        printf("%d\t",a[i]);
    }
}
// #include<stdio.h>
// #include<time.h>
// void main()
// {
//     int n;
//     printf("Enter the no of elements:\n");
//     scanf("%d",&n);
//     int arr[n];
//     for(int i=0;i<n;i++)
//     arr[i]=rand();
//     double start=clock();
//     for(int i=0;i<n;i++)
//     {
//         int min=i;
//         for(int j=i+1;j<n;j++)
//         {
//             if(arr[min]>arr[j])
//             {
//                 min =j;
//             }
//         }
//         int temp=arr[i];
//         arr[i]=arr[j];
//         arr[j]=temp;
//     }
//     double end=clock();
//     double diff=(end-start)/CLOCKS_PER_SEC;
//     printf("Sorting time:%f\n",diff);
    //printf("Sorted Array:\n");
    //for(int i=0;i<n;i++)
    //printf("%d\n",arr[i]);
//}